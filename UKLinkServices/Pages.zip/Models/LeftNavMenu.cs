﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UKLinkServices.Models
{
    public class LeftNavMenu
    {

        public int MenueId { get; set; }
        public string href { get; set; }
        public string menuName { get; set; }
        public string className { get; set; }
        public int[] RoleId { get; set; }
        public string BreadcrumbclassName { get; set; } 

    }
}
