﻿using System;
using System.ComponentModel.DataAnnotations;

namespace UKLinkServices.Models
{
    public class Mprn
    {
        public string MeterPointRef { get; set; }
        public string ExtractReason { get; set; }


    }
}
