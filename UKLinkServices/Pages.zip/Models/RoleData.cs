﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UKLinkServices.Models
{
    public class RoleData
    {

        public int RoleId { get; set; }

        public string Role { get; set; }

        public string[] menuName { get; set; }

    }
}
